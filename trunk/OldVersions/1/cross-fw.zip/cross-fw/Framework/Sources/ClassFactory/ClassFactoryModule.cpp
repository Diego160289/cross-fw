#include "Module.h"
#include "ClassFactory.h"

DECLARE_MODULE_ENTRY_POINT(
    "ClassFactory",
    28d24a57-9532-41a7-b3fd-67668bcca774,
    TYPE_LIST_1(IClassFactoryImpl))
