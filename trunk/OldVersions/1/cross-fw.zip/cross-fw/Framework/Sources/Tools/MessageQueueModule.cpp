#include "Module.h"
#include "MessageQueue.h"

DECLARE_MODULE_ENTRY_POINT(
    "Tools",
    d204eea6-4278-4282-b64c-767fec43d48d,
    TYPE_LIST_1(IMessageQueueManagerImpl))
