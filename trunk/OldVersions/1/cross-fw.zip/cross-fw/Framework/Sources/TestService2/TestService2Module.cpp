#include "Module.h"
#include "TestService2.h"

DECLARE_MODULE_ENTRY_POINT(
    "TestService2",
    826de039-5cd1-4483-8482-5ca20d06e057,
    TYPE_LIST_1(ITestService2Impl))
