#include "Module.h"
#include "Registry.h"

DECLARE_MODULE_ENTRY_POINT(
    "Registry",
    5631ec27-e1a0-430b-a723-4bf7575f06b5,
    TYPE_LIST_1(IRegistryImpl))

