#include "Module.h"
#include "TestService.h"

DECLARE_MODULE_ENTRY_POINT(
    "TestService",
    d9e520fc-ab19-4a49-aa10-dee583bb7dd5,
    TYPE_LIST_1(ITestServiceImpl))
