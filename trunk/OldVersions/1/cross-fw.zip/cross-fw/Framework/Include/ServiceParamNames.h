#ifndef __SERVICEPARAMNAMES_H__
#define __SERVICEPARAMNAMES_H__

namespace IFacesImpl
{

  static const char PrmClassFactorry[] = "ClassFactorry";
  static const char PrmServiceManager[] = "ServiceManager";

}

#endif // !__SERVICEPARAMNAMES_H__
